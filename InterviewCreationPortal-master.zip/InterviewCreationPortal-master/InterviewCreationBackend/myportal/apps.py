from django.apps import AppConfig


class MyportalConfig(AppConfig):
    name = 'myportal'
